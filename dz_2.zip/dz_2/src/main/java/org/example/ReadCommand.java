package org.example;

import java.util.Map;
import java.util.StringJoiner;

public class ReadCommand implements Command {
    private final Map<String, Vector3D> vectors;

    public ReadCommand(Map<String, Vector3D> vectors) {
        this.vectors = vectors;
    }

    @Override
    public String execute(String[] args) {
        StringJoiner joiner = new StringJoiner("\n");

        if (args.length > 1) {
            for (int i = 1; i < args.length; i++) {
                Vector3D vector = vectors.get(args[i]);
                if (vector != null) {
                    joiner.add(args[i] + ": " + vector);
                } else {
                    joiner.add("Вектор " + args[i] + " не найден.");
                }
            }
        } else {
            if (vectors.isEmpty()) {
                return "Нет сохраненных векторов.";
            }
            vectors.forEach((k, v) -> joiner.add(k + ": " + v));
        }

        return joiner.toString();
    }
}
