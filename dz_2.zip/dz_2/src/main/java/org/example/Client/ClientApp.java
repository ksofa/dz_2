package org.example.Client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientApp {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 8080);
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedReader console = new BufferedReader(new InputStreamReader(System.in))) {

            while (true) {
                System.out.print("Enter command: ");
                String command = console.readLine();

                writer.println(command);
                if ("exit".equalsIgnoreCase(command)) {
                    break;
                }

                System.out.print("Waiting for server response...");
                String response = reader.readLine();
                if (response == null) {
                    System.out.println("\nConnection to server was lost.");
                    break;
                }

                System.out.println("\nResponse: " + response);
            }

        } catch (Exception e) {
            System.out.println("Error connecting to server: " + e.getMessage());
        }
    }
}
