package org.example;

public class ExitCommand implements Command {
    @Override
    public String execute(String[] args) {
        return "Программа завершена.";
    }
}
