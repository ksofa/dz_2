package org.example.server;

import org.example.Vector3D;

import java.util.HashMap;
import java.util.Map;

public class StorageModule {

    private final Map<String, Vector3D> vectors = new HashMap<>();

    public void addVector(String name, Vector3D vector) {
        vectors.put(name, vector);
    }

    public Vector3D getVector(String name) {
        return vectors.get(name);
    }

    public Map<String, Vector3D> getVectors() {
        return vectors;
    }

    public void removeVector(String name) {
        vectors.remove(name);
    }

    public boolean vectorExists(String name) {
        return vectors.containsKey(name);
    }

    public int vectorCount() {
        return vectors.size();
    }

    public void clear() {
        vectors.clear();
    }
}

