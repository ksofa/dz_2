package org.example.server;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class RequestModule {

    public String readRequest(Socket socket) throws IOException {
        BufferedReader socketReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        return socketReader.readLine();
    }
}
