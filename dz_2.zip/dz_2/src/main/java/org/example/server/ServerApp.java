package org.example.server;

import org.example.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class ServerApp {

    private static final int PORT = 8080;

    // Модули
    private static final StorageModule storageModule = new StorageModule();
    private static final FileModule fileModule = new FileModule();
    private static final ResponseModule responseModule = new ResponseModule();
    private static final RequestModule requestModule = new RequestModule();
    private static ConnectionModule connectionModule;

    private static Map<String, Command> commands;

    static {
        commands = new HashMap<>();
        commands.put("create", new CreateCommand(storageModule.getVectors()));
        commands.put("read", new ReadCommand(storageModule.getVectors()));
        commands.put("exit", new ExitCommand());
        commands.put("range", new RangeCommand(storageModule.getVectors()));
        commands.put("angle", new AngleCommand(storageModule.getVectors()));

        // Предполагая, что у вас есть отдельные команды для крестного и скалярного произведений:
        commands.put("product", new ProductCommand(storageModule.getVectors()));

        // Тройное произведение:
        commands.put("product triple", new TripleProductCommand(storageModule.getVectors()));
    }

    public static void main(String[] args) {
        try {
            connectionModule = new ConnectionModule(PORT);
            System.out.println("Server started and listening on port " + PORT);

            // Загрузка данных из файла (если есть)
            try {
                Map<String, Vector3D> vectors = (Map<String, Vector3D>) fileModule.loadFromFile(storageModule.getVectors(), "vectors.dat");
                storageModule.getVectors().putAll(vectors);
            } catch (FileNotFoundException e) {
                System.out.println("Starting with an empty vectors database as vectors.dat file is not found.");
            } catch (ClassNotFoundException | IOException e) {
                System.out.println("Failed to load vectors from file: " + e.getMessage());
            }

            CommandExecutionModule commandExecutionModule = new CommandExecutionModule(commands);

            while (true) {
                try (Socket clientSocket = connectionModule.acceptConnection()) {
                    System.out.println("Client connected.");

                    while (!clientSocket.isClosed()) {
                        String request = requestModule.readRequest(clientSocket);

                        if (request == null || "exit".equalsIgnoreCase(request)) {
                            clientSocket.close(); // Close the connection if client sends "exit" or if the connection drops
                            break;
                        }

                        String response = commandExecutionModule.executeCommand(request);
                        responseModule.sendResponse(clientSocket, response);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (IOException e) {
            System.out.println("Unable to start the server on port " + PORT);
            e.printStackTrace();
        }
    }
}
