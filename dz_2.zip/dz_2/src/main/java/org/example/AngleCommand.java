package org.example;

import java.util.Map;

public class AngleCommand implements Command {
    private final Map<String, Vector3D> vectors;

    public AngleCommand(Map<String, Vector3D> vectors) {
        this.vectors = vectors;
    }

    @Override
    public String execute(String[] args) {
        try {
            double angleInRadians = Vector3D.angle(vectors.get(args[1]), vectors.get(args[2]));
            double angleInDegrees = Math.toDegrees(angleInRadians);
            return "Angle between vectors: " + angleInDegrees + " degrees";
        } catch (NullPointerException e) {
            return "Error: One of the vectors does not exist.";
        } catch (IndexOutOfBoundsException e) {
            return "Error: Not enough arguments.";
        }
    }
}
