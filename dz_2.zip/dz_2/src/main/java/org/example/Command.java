package org.example;

import java.io.IOException;

//реализую паттерн Command
public interface Command {
    String execute(String[] args) throws IOException, ClassNotFoundException;
}